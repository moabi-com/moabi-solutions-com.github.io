
int atexit(void (*function)(void)){
	return 0;
}

